Grupo 4: Robótica.
A continuación se encuentran las instrucciones para guaradar el recorrido, manejar el robot y plotear el recorrido en vivo.
Seguir los pasos de manera secuencial como se indica en el documento. 1-2-3-4-5-6

1. Para abrir roscore:
Abrir una terminal y correr roscore:
*******Comando.*******(Inicio)
roscore
*******Comando.*******(Fin)

2. Para abrir coppeliaSim:
Abrir en un terminal diferente coppeliaSim:
*******Comando.*******(Inicio)
cd ~/Descargas/VREP/
./coppeliaSim.sh
*******Comando.*******(Fin)
En coppeliaSim poner Open file y seleccionar el archivo (taller_1.ttt).
Poner en la velocidad de simulación: (dt=50ms).
Correr la simulación de coppeliaSim.

3. Para guadar los comandos:
En nueva terminal poner los siguientes comandos:
*******Comando.*******(Inicio)
cd ~/catkin_ws
catkin_make
source ~/catkin_ws/devel/setup.bash
cd src/robotica_pkg/
ls
cd scripts/
ls
chmod +x turtle_bot_interface_2.py
clear
*******Comando.*******(Fin)
Una vez se abre la interfaz ingresar el nombre de la interfaz.
Presionar el botón submit de abajo del texto ingresado.
Cerrar la interfaz con la "x" en la esquina superior derecha. (No cierre la terminal).

4. Para mover el robot:
En nueva terminal poner los siguientes comandos:
*******Comando.*******(Inicio)
cd ~/catkin_ws
catkin_make
source ~/catkin_ws/devel/setup.bash
cd src/robotica_pkg/
ls
cd scripts/
ls
rosrun robotica_pkg turtle_bot_teleop.py
clear
*******Comando.*******(Fin)
Ingresar la velocidad lineal: 10
Ingresar la velocidad angular: 1
Presionar los botones de movimiento. A continuación la descrición:
*******Descripción.*******(Inicio)
w: Arriba.
s: Abajo.
A: Izquierda.
D: Deerecha.
*******Descripción.*******(Fin)

5. Cuando se quiera plotear:
En nueva terminal poner los siguientes comandos:
*******Comando.*******(Inicio)
cd ~/catkin_ws
catkin_make
source ~/catkin_ws/devel/setup.bash
cd src/robotica_pkg/
ls
cd scripts/
ls
rosrun robotica_pkg turtle_bot_interface.py
clear
*******Comando.*******(Fin)

6. Verificar que se guardó
Abrir archivos y dirigirse a la carpeta en que se encuentran los script.
Seleccionar el .txt con el nombre correspondiente al ingresado.
Ver contenido.
