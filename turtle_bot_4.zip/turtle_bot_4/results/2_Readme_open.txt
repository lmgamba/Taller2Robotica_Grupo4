Readme Punto 4

Una vez haya verificado que tanto roscore esté corriendo como coppelia hay que ejecutar los comandos

catkin_make
source devel/setup.bash

Esto para actualizar las variables disponibles en el workspace. Posteriormente se ejecuta el comando

rosrun turtle_bot_4 turtle_bot_player.py

Debería salir un print mencionando que el modelo está listo para ser ejecutado. Es este punto el que sistema está esperando a que el usuario haga un llamado al servicio,

Antes de comenzar con la simulación, es esencial verificar que las instrucciones efectivamente estén en un archivo .txt (ver extensión) pero tambiés es esencial que esté ubicado apropiadamente. Así, en otra consola se puede crear un archivo direccion.py, darle los permisos de ejecución, volver a correr catkin_make y soruce/devel.bash  y finalmente ver que imprime en consola el siguiente código:

#!/usr/bin/env python3

import os

print(os.getcwd())


Así, en caso de que le salga un error vuelva a correr el código y coloque el archivo .txt donde corresponde.

Finalmente, el siguiente paso para ejecutar el servicio radica en llamar a dicho servicio desde el terminal. Así,
probablemente sea buena idea correr el comando

rosservice list

para validar que el servicio está funciondo. En caso de que dicho sea el caso se deberán verificar todos los pasos anteriores, incluído el archivo .srv que si bien no se ejecuta sí se debe ejecutar.

Finalmente se corre en consola

rosservive call /sim_datos_user velocidad\_lineal velocidad\_angular nombre del archivo

IMPORTANTE: El nombre del archivo no incluye el .txt.

Así, se debería poder ver la simulación nuevamente desde Coppelia
