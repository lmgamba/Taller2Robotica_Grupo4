#!/usr/bin/env python3
import rospy
from tkinter import *
from tkinter import ttk
from std_msgs.msg import String
import threading

root = Tk()
root.geometry("450x180")

def Submit_save():
    global Guardar_flag
    global Guardar_name
    Guardar_flag = "True"
    print("-----------------------------------------")
    print("Acción seleccionada: Save")
    Guardar_name = Save_answer.get()
    print("Nombre del archivo:"+" "+Guardar_name)
    print("-----------------------------------------")
def Submit_open():
    global Abierto_flag
    global Abierto_name
    Abrir_flag = True
    print("-----------------------------------------")
    print("Acción seleccionada: Open")
    Abrir_name = Open_answer.get()
    print("Nombre del archivo:"+" "+Abrir_name)
    print("-----------------------------------------")

Guardar_flag = "False"
Guardar_name = ""
Abrir_flag = False
Abrir_name = ""

Save_text = Label(root,text = "Save:").place(x = 40,y = 20)
Save_answer = StringVar()
Save_name = Entry(root,width = 40,textvariable=Save_answer).place(x = 90,y = 20)
Save_submit = Button(root,text = "Submit",command=Submit_save).place(x = 40, y = 60)
Open_text = Label(root,text = "Open:").place(x = 40,y = 100)
Open_answer = StringVar()
Open_name = Entry(root,width = 40,textvariable=Open_answer).place(x = 90,y = 100)
Open_submit = Button(root,text = "Submit",command=Submit_open).place(x = 40, y = 140)
root.mainloop()
#############################################################
def inicio():
    pub_Guardar_flag = rospy.Publisher('turtlebot_Guardar_flag', String, queue_size=10)
    pub_Guardar_name = rospy.Publisher('turtlebot_Guardar_name', String, queue_size=10)
    rospy.init_node('turtle_bot_interface_2', anonymous=True)
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        pub_Guardar_flag.publish(Guardar_flag)
        pub_Guardar_name.publish(Guardar_name)
        print("Enviando...")
        rate.sleep()
if __name__=='__main__':
    inicio()
#############################################################
