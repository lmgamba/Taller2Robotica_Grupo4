#!/usr/bin/env python3
import rospy
import numpy as np
from geometry_msgs.msg import Twist
import matplotlib.pyplot as plt
from matplotlib import pyplot
from matplotlib.animation import FuncAnimation
from random import randrange
import threading

plt.style.use('ggplot')
x_data = []
y_data = []
figure = pyplot.figure()
line, = pyplot.plot_date(x_data,y_data,'-')

def callback(data):
    Pos_linear_x = data.linear.x
    x_data.append(Pos_linear_x)
    Pos_linear_y = data.linear.y
    y_data.append(Pos_linear_y)
def listener():
    rospy.init_node('turtle_bot_interface', anonymous=True)
    rospy.Subscriber("turtlebot_position", Twist, callback)
    rospy.spin()
def grafico(frame):
    line.set_data(x_data,y_data)
    figure.gca().relim()
    figure.gca().autoscale_view()
    return line,
def plot():
    animacion = FuncAnimation(figure,grafico,interval=500)
    pyplot.show()

t = threading.Thread(target=plot,daemon=True)

t.start()
if __name__=='__main__':
    listener()
