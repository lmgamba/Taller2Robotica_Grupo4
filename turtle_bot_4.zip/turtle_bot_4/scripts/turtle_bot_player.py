#!/usr/bin/env python3
from turtle_bot_4.srv import sim_datos_user,sim_datos_userResponse
from geometry_msgs.msg import Twist
import time
import rospy
import os

def on_press(instruccion):
    global Velocidad_lineal
    global Velocidad_angular
    global Input_velocidad_lineal
    global Input_velocidad_angular

    if instruccion == 'w':
        print('Arriba')
        Velocidad_lineal = Input_velocidad_lineal
        Velocidad_angular = 0
    if instruccion == 's':
        print('Abajo')
        Velocidad_lineal = -Input_velocidad_lineal
        Velocidad_angular = 0
    if instruccion == 'a':
        print('Derecha')
        Velocidad_lineal = 0
        Velocidad_angular = Input_velocidad_angular
    if instruccion == 'd':
        print('Izquierda')
        Velocidad_lineal = 0
        Velocidad_angular = -Input_velocidad_angular

def inicio(ordenes):
    global Velocidad_lineal
    global Velocidad_angular
    global Input_velocidad_lineal
    global Input_velocidad_angular

    print("hola estoy en inicio")
    pub = rospy.Publisher('turtlebot_cmdVel', Twist, queue_size=10)
    #rospy.init_node('turtle_bot_player', anonymous=True)
    rate = rospy.Rate(10)
    msg = Twist()
    while not rospy.is_shutdown():
        for each_order in ordenes:
            on_press(each_order)
            msg.linear.x = Velocidad_lineal
            msg.angular.z = Velocidad_angular
            rospy.loginfo(msg)
            pub.publish(msg)
            time.sleep(0.1)
            rate.sleep()
        break

def lectura_ord(file_name):
    f = open(file_name,"r")
    if f.mode == 'r':
        contents = f.read()
        ordenes = contents.split()
        print("Ordenes leidas: ", ordenes)
        return ordenes

def handle_sim_datos_user(req):
    global Velocidad_lineal
    global Velocidad_angular
    global Input_velocidad_lineal
    global Input_velocidad_angular

    print("Entró acá") #El cod NO llega hasta acá
    file_name = req.nombre_archivo
    file_name += ".txt"
    Input_velocidad_lineal = float(req.velocidad_lineal)
    Input_velocidad_angular = float(req.velocidad_angular)
    Velocidad_lineal = 0
    Velocidad_angular = 0
    ordenes = lectura_ord(file_name) #Lee el archivo txt y arregla una lista
    inicio(ordenes) #Las ejecuta como el punto 1
    print("Fin de simulación")
    return sim_datos_userResponse("Terminé")

def sim_datos_user_server(): #Función ejecitada en el mai
    rospy.init_node('turtle_bot_player')
    s = rospy.Service('sim_datos_user', sim_datos_user, handle_sim_datos_user)
    print("Ready to start simulation")
    rospy.spin()

if __name__ == "__main__":
    sim_datos_user_server()
