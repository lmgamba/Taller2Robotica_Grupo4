#!/usr/bin/env python3
import rospy
from pynput import keyboard
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import threading
###############################################################################
def callback_Guardar_flag(data_flag):
    a = data_flag
    global Guardar_flag
    if data_flag == a:
        Guardar_flag = True
    return False
def callback_Guardar_name(data_name):
    global Guardar_flag
    global f
    global Guardar_name
    Guardar_name = data_name
    if Guardar_flag == True:
        Documento = str(Guardar_name)[6:]
        print("Guardando en:"+" "+Documento)
        f = open(Documento + ".txt", "a+")
    return False
def listener_flag():
    rospy.Subscriber("turtlebot_Guardar_flag", String, callback_Guardar_flag)
def listener_name():
    rospy.Subscriber("turtlebot_Guardar_name", String, callback_Guardar_name)
    rospy.spin()
###############################################################################
def on_press(key):
    global f
    global instruccion
    global Guardar_flag
    global Velocidad_lineal
    global Velocidad_angular
    try:
        instruccion = key.char
    except:
        instruccion = key.name
    if instruccion == 'w':
        print('Arriba')
        Velocidad_lineal = Input_velocidad_lineal
        Velocidad_angular = 0
    if instruccion == 's':
        print('Abajo')
        Velocidad_lineal = -Input_velocidad_lineal
        Velocidad_angular = 0
    if instruccion == 'a':
        print('Derecha')
        Velocidad_lineal = 0
        Velocidad_angular = Input_velocidad_angular
    if instruccion == 'd':
        print('Izquierda')
        Velocidad_lineal = 0
        Velocidad_angular = -Input_velocidad_angular
    ###############################################################################
    if Guardar_flag == True:
        if instruccion == 'w' or instruccion == 'a'or instruccion == 's' or instruccion == 'd':
            f.write(instruccion + "\r\n")
    return False
    ###############################################################################
def on_release(key):
    global Velocidad_lineal
    global Velocidad_angular
    print('{0} released'.format(key))
    if key == keyboard.Key.esc:
        return False
    Velocidad_lineal = 0
    Velocidad_angular = 0
    return False
def inicio():
    print("hola estoy en inicio")
    pub = rospy.Publisher('turtlebot_cmdVel', Twist, queue_size=10)
    rospy.init_node('turtle_bot_teleop', anonymous=True)
    m.start()
    n.start()
    rate = rospy.Rate(10)
    msg = Twist()
    while not rospy.is_shutdown():
        listener = keyboard.Listener(on_press=on_press, on_release=on_release)
        listener.start()
        listener.join()
        msg.linear.x = Velocidad_lineal
        msg.angular.z = Velocidad_angular
        rospy.loginfo(msg)
        pub.publish(msg)
        rate.sleep()

Guardar_flag = False
Guardar_name = ""
m = threading.Thread(target=listener_flag,daemon=True)
n = threading.Thread(target=listener_name,daemon=True)

if __name__=='__main__':
    Input_velocidad_lineal = float(input('Ingresar Velocidad lineal entre 0 y 70:'))
    Input_velocidad_angular = float(input('Ingresar Velocidad angular entre 0 y 180:'))
    Velocidad_lineal = 0
    Velocidad_angular = 0
    inicio()
